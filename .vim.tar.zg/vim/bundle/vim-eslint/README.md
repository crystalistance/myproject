# vim-eslint

###Installation

Install ESLint.
If you are using pathogen:

```vim
cd ~/.vim/bundle
git clone https://github.com/sfger/vim-eslint.git
```
If not, simply save plugin/eslint.vim to your .vim/plugin folder.

###Usage
* ,c : Check javascript syntax;
* ,h : When Quickfix list showed, hide it.
